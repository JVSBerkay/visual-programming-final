﻿namespace Ozcelik_Elektronik_Magza
{
    partial class AnaSayfa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.anaSayfaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bilgisayarlarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.laptoplarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.masaustuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adminGirisiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.laptoplarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.masaüstüBilgisayarlarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kayitOlToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uyeOlToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.menuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.anaSayfaToolStripMenuItem,
            this.bilgisayarlarToolStripMenuItem,
            this.adminGirisiToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1103, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // anaSayfaToolStripMenuItem
            // 
            this.anaSayfaToolStripMenuItem.Name = "anaSayfaToolStripMenuItem";
            this.anaSayfaToolStripMenuItem.Size = new System.Drawing.Size(107, 29);
            this.anaSayfaToolStripMenuItem.Text = "Ana Sayfa";
            // 
            // bilgisayarlarToolStripMenuItem
            // 
            this.bilgisayarlarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.laptoplarToolStripMenuItem,
            this.masaustuToolStripMenuItem});
            this.bilgisayarlarToolStripMenuItem.Name = "bilgisayarlarToolStripMenuItem";
            this.bilgisayarlarToolStripMenuItem.Size = new System.Drawing.Size(121, 29);
            this.bilgisayarlarToolStripMenuItem.Text = "Bilgisayarlar";
            // 
            // laptoplarToolStripMenuItem
            // 
            this.laptoplarToolStripMenuItem.Name = "laptoplarToolStripMenuItem";
            this.laptoplarToolStripMenuItem.Size = new System.Drawing.Size(173, 34);
            this.laptoplarToolStripMenuItem.Text = "Dizustu";
            this.laptoplarToolStripMenuItem.Click += new System.EventHandler(this.laptoplarToolStripMenuItem_Click);
            // 
            // masaustuToolStripMenuItem
            // 
            this.masaustuToolStripMenuItem.Name = "masaustuToolStripMenuItem";
            this.masaustuToolStripMenuItem.Size = new System.Drawing.Size(173, 34);
            // 
            // adminGirisiToolStripMenuItem
            // 
            this.adminGirisiToolStripMenuItem.Name = "adminGirisiToolStripMenuItem";
            this.adminGirisiToolStripMenuItem.Size = new System.Drawing.Size(16, 29);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(739, 0);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(231, 26);
            this.textBox1.TabIndex = 1;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.groupBox1.Location = new System.Drawing.Point(117, 123);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(829, 320);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "FIRSATLARI YAKALA";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 50);
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(0, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 50);
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.AutoSize = true;
            this.groupBox2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox2.ForeColor = System.Drawing.SystemColors.Highlight;
            this.groupBox2.Location = new System.Drawing.Point(76, 64);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.groupBox2.Size = new System.Drawing.Size(894, 53);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "OZCELIK ELEKTRONIK";
            // 
            // menuStrip2
            // 
            this.menuStrip2.BackColor = System.Drawing.Color.SkyBlue;
            this.menuStrip2.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.laptoplarToolStripMenuItem1,
            this.masaüstüBilgisayarlarToolStripMenuItem,
            this.kayitOlToolStripMenuItem,
            this.uyeOlToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(836, 33);
            this.menuStrip2.TabIndex = 0;
            this.menuStrip2.Text = "menuStrip2";
            this.menuStrip2.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip2_ItemClicked);
            // 
            // laptoplarToolStripMenuItem1
            // 
            this.laptoplarToolStripMenuItem1.Name = "laptoplarToolStripMenuItem1";
            this.laptoplarToolStripMenuItem1.Size = new System.Drawing.Size(185, 29);
            this.laptoplarToolStripMenuItem1.Text = "Dizüstü Bilgisayarlar";
            this.laptoplarToolStripMenuItem1.Click += new System.EventHandler(this.laptoplarToolStripMenuItem1_Click_1);
            // 
            // masaüstüBilgisayarlarToolStripMenuItem
            // 
            this.masaüstüBilgisayarlarToolStripMenuItem.Name = "masaüstüBilgisayarlarToolStripMenuItem";
            this.masaüstüBilgisayarlarToolStripMenuItem.Size = new System.Drawing.Size(202, 29);
            this.masaüstüBilgisayarlarToolStripMenuItem.Text = "Masaüstü Bilgisayarlar";
            this.masaüstüBilgisayarlarToolStripMenuItem.Click += new System.EventHandler(this.masaüstüBilgisayarlarToolStripMenuItem_Click);
            // 
            // kayitOlToolStripMenuItem
            // 
            this.kayitOlToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.kayitOlToolStripMenuItem.Name = "kayitOlToolStripMenuItem";
            this.kayitOlToolStripMenuItem.Size = new System.Drawing.Size(89, 29);
            this.kayitOlToolStripMenuItem.Text = "Kayit Ol";
            this.kayitOlToolStripMenuItem.Click += new System.EventHandler(this.kayitOlToolStripMenuItem_Click_1);
            // 
            // uyeOlToolStripMenuItem
            // 
            this.uyeOlToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.uyeOlToolStripMenuItem.Name = "uyeOlToolStripMenuItem";
            this.uyeOlToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 0, 6, 0);
            this.uyeOlToolStripMenuItem.Size = new System.Drawing.Size(95, 29);
            this.uyeOlToolStripMenuItem.Text = "Uye Girisi";
            this.uyeOlToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.uyeOlToolStripMenuItem.Click += new System.EventHandler(this.uyeOlToolStripMenuItem_Click);
            this.uyeOlToolStripMenuItem.DoubleClick += new System.EventHandler(this.uyeOlToolStripMenuItem_DoubleClick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Location = new System.Drawing.Point(84, 95);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(652, 272);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 2;
            this.pictureBox5.TabStop = false;
            // 
            // AnaSayfa
            // 
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackgroundImage = global::Ozcelik_Elektronik_Magza.Properties.Resources.cool_background;
            this.ClientSize = new System.Drawing.Size(836, 477);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.menuStrip2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "AnaSayfa";
            this.Load += new System.EventHandler(this.AnaSayfa_Load_1);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem anaSayfaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bilgisayarlarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adminGirisiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem laptoplarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem masaustuToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ToolStripMenuItem laptoplarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem masaüstüBilgisayarlarToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox5;
        public System.Windows.Forms.MenuStrip menuStrip2;
        public System.Windows.Forms.ToolStripMenuItem uyeOlToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem kayitOlToolStripMenuItem;
    }
}