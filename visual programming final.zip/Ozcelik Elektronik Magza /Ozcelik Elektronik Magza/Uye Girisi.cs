﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Net.Http.Headers;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ozcelik_Elektronik_Magza
{
    public partial class Uye_Girisi : Form
    {
        public MySqlConnection veritabanibaglantisi = new MySqlConnection("server=localhost; uid=root; pwd=; database=elektronik");
        AnaSayfa anaSayfa= new AnaSayfa();
        public Uye_Girisi(AnaSayfa anaSayfa)
        {
            InitializeComponent();
            this.anaSayfa = anaSayfa;
        }

        private void Uye_Girisi_Load(object sender, EventArgs e)
        {
            textBox2.PasswordChar = '*';
        }
        //202151502016
        public bool GirisDurumu;
        public string kullaniciadi;

        private void button1_Click(object sender, EventArgs e)
        {

            veritabanibaglantisi.Open();

            
            string sifre;
            kullaniciadi = textBox1.Text;
            sifre=textBox2.Text;

            MySqlCommand komut = new MySqlCommand("SELECT * FROM uyeler WHERE Kullanici='" + kullaniciadi + "' and sifre='" + sifre + "'" , veritabanibaglantisi);
            MySqlDataReader okuyucu=komut.ExecuteReader();
            if (okuyucu.Read())
            {
                MessageBox.Show("Giris Basarili !");
            }
            else
            {
                MessageBox.Show("Hatali Giris Yaptiniz");
            }
            
            veritabanibaglantisi.Close();
            /*
            anaSayfa.uyeOlToolStripMenuItem.Text = kullaniciadi;
            anaSayfa.uyeOlToolStripMenuItem.Size = new System.Drawing.Size(25, 25);
            anaSayfa.uyeOlToolStripMenuItem.BackColor= System.Drawing.Color.LightBlue;
            GirisDurumu = true;
              */
            GirisDurumu = true;
            this.Hide();
            anaSayfa.Show();
          

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Uye_olma uye_Olma = new Uye_olma(anaSayfa);
            uye_Olma.Show();
            this.Hide();
        }

        private void Uye_Girisi_FormClosed(object sender, FormClosedEventArgs e)
        {
            anaSayfa.Show();
            this.Hide();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
