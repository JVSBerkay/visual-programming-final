﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
namespace Ozcelik_Elektronik_Magza
{
    public partial class AnaSayfa : Form
    {
        public AnaSayfa()
        {
            InitializeComponent();
        }
    public    MySqlConnection veritabanibaglantisi = new MySqlConnection("server=localhost; uid=root; pwd=; database=elektronik");
        DataTable tablo = new DataTable();

        private void laptoplarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DizüstübilgisayarMenü laptoplar = new DizüstübilgisayarMenü(this);
            laptoplar.Show();
            this.Hide();

        }

        
        

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
            
        }
        public bool GirisDurumu;
        private void AnaSayfa_Load_1(object sender, EventArgs e)
        {
            pictureBox5.ImageLocation = "https://s9.gifyu.com/images/ozceLIK-A.S.gif";
            Uye_Girisi uye_Girisi = new Uye_Girisi(this);
            if (uye_Girisi.GirisDurumu = false)
            {
                //202151502016 
            }
            else
            {
                kayitOlToolStripMenuItem.Visible = false;
                uyeOlToolStripMenuItem.Text = uye_Girisi.kullaniciadi;
                uyeOlToolStripMenuItem.Size = new System.Drawing.Size(25, 25);
                uyeOlToolStripMenuItem.BackColor = System.Drawing.Color.LightBlue;
            }
        }
        private void laptoplarToolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            DizüstübilgisayarMenü laptoplar = new DizüstübilgisayarMenü(this);
            laptoplar.Show();
            this.Hide();
        }

        private void masaüstüBilgisayarlarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            masaüstübilgisayarMenü masaustupc = new masaüstübilgisayarMenü();
            masaustupc.Show();
            this.Hide();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void uyeOlToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Uye_Girisi uye_Girisi = new Uye_Girisi(this);
            uye_Girisi.Show();
            this.Hide();
        }

      

        private void uyeOlToolStripMenuItem_DoubleClick(object sender, EventArgs e)
        {
            
        }

        private void kayitOlToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Uye_olma uye_Olma = new Uye_olma(this);
            uye_Olma.Show();
            this.Hide();
        }

        private void menuStrip2_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
           
        }
    }
}
